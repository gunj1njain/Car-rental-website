from django.contrib import admin
from .models import Car,Order,Contact

admin.site.register(Car)
admin.site.register(Order)
admin.site.register(Contact)
